package objects;

import java.util.Date;

public class Usuario {
	
	private String nome;
	private int idade;
	private int status;
	private Date dataM;
	
	
	public Usuario(String nome, int idade, int status, Date dataM) {
		this.nome = nome;
		this.idade = idade;
		this.status = status;
		this.dataM = dataM;
	}

	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public int getIdade() {
		return idade;
	}
	public void setIdade(int idade) {
		this.idade = idade;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public Date getDataM() {
		return dataM;
	}
	public void setDataM(Date dataM) {
		this.dataM = dataM;
	}
	
	
	

	
	
	
	
	
	
}

