package pacote1;

import java.util.ArrayList;

import objects.Usuario;

public class Persist {

	private ArrayList<Usuario> lista;
	
	public Persist() {
	
		this.lista = new ArrayList<>();
	}

	public ArrayList<Usuario> getLista() {
		return lista;
	}

	public void setLista(ArrayList<Usuario> lista) {
		this.lista = lista;
	}
	
	public boolean check(){
		return this.lista.isEmpty();
	}
}
