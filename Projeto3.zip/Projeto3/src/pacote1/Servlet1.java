package pacote1;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.websocket.Session;

import org.apache.catalina.connector.Request;

import objects.Usuario;

/**
 * Servlet implementation class Servlet1
 */
@WebServlet("/Servlet1")
public class Servlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Servlet1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		HttpSession sessao = request.getSession();
		
		//Persist lista = new Persist();
		
		ArrayList<Usuario> lista = null;
		
		SimpleDateFormat dt = new SimpleDateFormat("yyyy-MM-dd");
		
		String n = request.getParameter("nome");
		int i = Integer.parseInt(request.getParameter("idade"));
		int c = Integer.parseInt(request.getParameter("ciclo"));
		
		Date d = null;
		
		try {
			d = dt.parse(request.getParameter("data"));
			//System.out.println(request.getParameter("data"));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		/*
		double soma = 0;
		if(c == 1){
			for (int v = 0; v < 28; v++) {
				soma += (24*60*60*1000);
			}
			dataN.setTime((long) (dataN.getTime()+soma));
			System.out.println("FODASE"+dataN);
		}
		
		else if(c == 2){
			for (int b = 0; b < 23; b++) {
				soma += (24*60*60*1000);
			}
			dataN.setTime((long) (dataN.getTime()+soma));
			System.out.println("FODASE"+dataN);
		}
		*/
		
		Usuario uso = new Usuario(n,i,c,d);
		
		
	   if(sessao.getAttribute("us") != null){
		   
		   lista = (ArrayList<Usuario>) sessao.getAttribute("us");
		
		}else{
			
			lista = new ArrayList<>();
		}
		
		lista.add(uso);

		sessao.setAttribute("us", lista);
		System.out.println(uso.getDataM());
		
		getServletContext().getRequestDispatcher("/view.jsp").forward(request, response);
		
		//System.out.println(uso.getNome());
		//System.out.println(uso.getIdade());
		//System.out.println(uso.getStatus());
		//System.out.println(uso.getDataM());
	}
	public Date ciclo(Date x, int y){
		
		Date dataN = x;
		
		double soma = 0;
		if(y == 1){
			for (int i = 0; i < 28; i++) {
				soma += (24*60*60*1000);
			}
			dataN.setTime((long) (dataN.getTime()+soma));
			System.out.println("FODASE"+dataN);
		}
		
		else if(y == 2){
			for (int i = 0; i < 23; i++) {
				soma += (24*60*60*1000);
			}
			dataN.setTime((long) (dataN.getTime()+soma));
			System.out.println("FODASE"+dataN);
		}
		return dataN;
	}

}
